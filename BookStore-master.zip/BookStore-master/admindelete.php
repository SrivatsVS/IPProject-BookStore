<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname=    "cargo";
$cname=$_POST['cname'];
// Create connection
$conn = mysqli_connect($servername, $username, $password,$dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$sql="delete from register where cname='$cname';";
$result=mysqli_query($conn,$sql);
error_reporting(E_ALL ^ E_WARNING); 
if($result)
{   echo "<script type='text/javascript'>alert('Successfully Deleted!'); window.open('cargoadmin.html','_self');</script>";
    $conn->close();
}
else
 echo "Error: " . $sql . "<br>" . mysqli_error($conn);
?>