<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname= "cargo";

$user=$_POST['user'];
$pswd=$_POST['password'];

// Create connection
$conn = mysqli_connect($servername, $username, $password,$dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$query = mysqli_query($conn,"SELECT * FROM admin WHERE name='$user' AND password='$pswd' ");
$rows = mysqli_num_rows($query);
if ($rows>0) {
 header("location: admin.html"); 
} else {
$error = "Username or Password is invalid";
echo "<script type='text/javascript'>alert('$error');</script>";
}

?>