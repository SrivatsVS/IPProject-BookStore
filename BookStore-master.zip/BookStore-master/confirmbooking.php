<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <title>Booking Confirmation</title>
</head>
<style>
    .btns{
    background-color: #4CAF50;
    color: white;
    padding: 12px;
    margin: 10px 0;
    border: none;
    width: 100%;
    border-radius: 3px;
    cursor: pointer;
    font-size: 17px;
    }
</style>
<body>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname=    "bookstore";
$cname = $_POST['name'];
$cnumber = $_POST['cardnumber'];
$expmonth = $_POST['expmonth'];
$expyear = $_POST['expyear'];
$cvv = $_POST['cvv'];
$rate=$_POST['rate'];
$conn = mysqli_connect($servername, $username, $password,$dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$query = mysqli_query($conn,"SELECT * FROM card WHERE cno='$cnumber' AND cvv='$cvv' AND expmon='$expmonth' AND expyear='$expyear'");
$rows = mysqli_num_rows($query);
if ($rows == 1) {
         $mod = mysqli_query($conn,"select balance from card WHERE cno='$cnumber' AND cvv='$cvv' ");
        $queryRows = $mod->fetch_row();
        $old = $queryRows[0];
        
         $mod1 = mysqli_query($conn,"select name from card WHERE cno='$cnumber' AND cvv='$cvv' ");
        $queryRows2 = $mod1->fetch_row();
        $old1 = $queryRows2[0];


      
        $mon = mysqli_query($conn,"select mrp from products where pid='$rate'");
        $queryRows1 = $mon->fetch_row();
        $mrp = $queryRows1[0];
        $sum= $old-$mrp;
        $newupd= mysqli_query($conn,"UPDATE card set balance='$sum' WHERE cno='$cnumber' AND cvv='$cvv'");
        $updbook= mysqli_query($conn,"UPDATE products set Available= Available-1 where pid='$rate'");
        $ins= mysqli_query($conn,"insert into cart(Customer,Product) values ('$cname','$rate')");
        echo "Your Booking has been confirmed.";
       
    } 
    

else {
    $error = "Card Credentials are incorrect!";
    echo "<script type='text/javascript'>alert('$error');</script>";
   
    }
?>
 <center>
    <div class='container-fluid' width=50% height=50%>
        <button class='btns' onclick="window.open('index.php','_self');">Go Back to Home Page</button>
    </div>
</center>

</body>
</html>